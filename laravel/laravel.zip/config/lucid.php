<?php

return [
    /*
     |--------------------------------------------------------------------------
     | Dashboard
     |--------------------------------------------------------------------------
     |
     | By default /lucid/dashboard is available when env('APP_DEBUG') is true.
     | If you set this value to "true" it will be always accessible even on
     | production environment.
     |
     */
    'dashboard'     => null,
];



<?php $__env->startSection('content'); ?>
    <div id="module-change" class="vuetify">
        <change-container-component />
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('crud_list_styles'); ?>
    <!-- Styles -->
    <link href="<?php echo e(mix('modules/change/css/app.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('crud_list_scripts'); ?>
    <script>
    // global baseRoute
    var baseRoute = "/<?php echo e(config('backpack.base.route_prefix', 'admin')); ?>";
    </script>

    <script src="<?php echo e(mix('modules/change/js/manifest.js')); ?>" defer></script>
    <script src="<?php echo e(mix('modules/change/js/vendor.js')); ?>" defer></script>
    <script src="<?php echo e(mix('modules/change/js/app.js')); ?>" defer></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('crud::list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Code\camunda-demo\laravel\resources\views/modules/change/change.blade.php ENDPATH**/ ?>
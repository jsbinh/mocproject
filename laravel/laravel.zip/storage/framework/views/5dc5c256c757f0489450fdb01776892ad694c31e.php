<!-- This file is used to store topbar (right) items -->



<?php /**PATH D:\Code\camunda-demo\laravel\resources\views/vendor/backpack/base/inc/topbar_right_content.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
<div class="jumbotron mb-2">

    <h1 class="display-3">Welcome!</h1>

    <p>Use the sidebar to the left to create, edit or delete content.</p>

    <p class="lead">
        <a class="btn btn-primary" href="/<?php echo e(config('backpack.base.route_prefix', 'admin')); ?>/change2" role="button">Enter Change Management</a>
        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(backpack_view('blank'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Code\camunda-demo\laravel\resources\views/vendor/backpack/base/dashboard.blade.php ENDPATH**/ ?>